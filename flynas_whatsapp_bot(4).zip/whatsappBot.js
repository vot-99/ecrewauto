const makeWASocket = require('@whiskeysockets/baileys').default;
const { useSingleFileAuthState } = require('@whiskeysockets/baileys');
const { chromium } = require('playwright');
const { state, saveState } = useSingleFileAuthState('./auth.json');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const usersPath = path.join(__dirname, 'users.json');
let allowedNumbers = require(usersPath);
const OWNER_PHONE = process.env.OWNER_PHONE;
const accounts = require('./accounts.json');

async function saveUsers() {
  fs.writeFileSync(usersPath, JSON.stringify(allowedNumbers, null, 2));
}

function isAllowed(jid) {
  return allowedNumbers.some(num => jid.includes(num.replace('+', '')));
}

function getUserCreds(jid) {
  const phone = '+' + jid.replace(/[^0-9]/g, '').slice(-12);
  return accounts[phone];
}

async function flynasLoginAndCheckIn(creds, takeScreenshot = false) {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();
  try {
    await page.goto('https://ecrewaz.flynas.com/eCrew?CHK=1');
    await page.fill('input[type="text"]', creds.CREW_ID);
    await page.fill('input[type="password"]', creds.PASSWORD);
    await page.click('.webix_button');
    await page.waitForTimeout(3000);
    if (takeScreenshot) {
      const path = '/mnt/data/schedule.png';
      await page.screenshot({ path, fullPage: true });
      return path;
    } else {
      await page.waitForSelector('text=Check In', { timeout: 8000 });
      await page.click('text=Check In');
    }
  } catch (e) {
    console.error("Login/check-in error:", e);
  } finally {
    await browser.close();
  }
}

async function sendMainMenu(sock, jid) {
  const buttons = [
    { buttonId: '#login', buttonText: { displayText: '🔐 Login' }, type: 1 },
    { buttonId: '#checkin', buttonText: { displayText: '🛫 Check In' }, type: 1 },
    { buttonId: '#screenshot', buttonText: { displayText: '📸 Get Schedule' }, type: 1 },
    { buttonId: '#help', buttonText: { displayText: '🧠 Help' }, type: 1 },
    { buttonId: '#logout', buttonText: { displayText: '🚪 Logout' }, type: 1 },
  ];
  await sock.sendMessage(jid, {
    text: '🤖 What would you like to do?',
    buttons,
    headerType: 1
  });
}

async function startBot() {
  const sock = makeWASocket({ auth: state, printQRInTerminal: true });
  sock.ev.on('creds.update', saveState);

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message) return;
    const jid = msg.key.remoteJid;
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || msg.message?.buttonsResponseMessage?.selectedButtonId;
    const isOwner = jid.includes(OWNER_PHONE.replace('+', ''));

    if (isOwner && text?.startsWith("add ")) {
      const num = text.split(" ")[1];
      if (num && !allowedNumbers.includes(num)) {
        allowedNumbers.push(num);
        saveUsers();
        await sock.sendMessage(jid, { text: `✅ Added ${num}` });
      }
      return;
    }

    if (isOwner && text?.startsWith("remove ")) {
      const num = text.split(" ")[1];
      allowedNumbers = allowedNumbers.filter(n => n !== num);
      saveUsers();
      await sock.sendMessage(jid, { text: `❌ Removed ${num}` });
      return;
    }

    if (!isAllowed(jid)) {
      await sock.sendMessage(jid, { text: "❌ You're not authorized to use this bot." });
      return;
    }

    const creds = getUserCreds(jid);
    if (!creds) {
      await sock.sendMessage(jid, { text: "⚠️ No credentials found. Ask the owner to add your account." });
      return;
    }

    if (text?.toLowerCase() === 'menu') {
      return await sendMainMenu(sock, jid);
    }

    if (text === '#login') {
      await sock.sendMessage(jid, { text: '🔐 Logging in...' });
      await flynasLoginAndCheckIn(creds);
      await sock.sendMessage(jid, { text: '✅ Logged in!' });
    }

    if (text === '#checkin') {
      await sock.sendMessage(jid, { text: '🛫 Checking in...' });
      await flynasLoginAndCheckIn(creds);
      await sock.sendMessage(jid, { text: '✅ Check-in complete!' });
    }

    if (text === '#screenshot') {
      await sock.sendMessage(jid, { text: '📸 Getting schedule...' });
      const path = await flynasLoginAndCheckIn(creds, true);
      if (fs.existsSync(path)) {
        await sock.sendMessage(jid, { image: { url: path }, caption: '🗓️ Your schedule' });
      } else {
        await sock.sendMessage(jid, { text: '❌ Failed to get screenshot.' });
      }
    }

    if (text === '#help') {
      const help = `
📲 Commands:
#login – Login
#checkin – Check-in
#screenshot – Schedule screenshot
menu – Show button menu
#logout – Stop bot

👑 Admin:
add +9665XXXXXXX
remove +9665XXXXXXX
      `;
      await sock.sendMessage(jid, { text: help });
    }

    if (text === '#logout') {
      await sock.sendMessage(jid, { text: '👋 Goodbye!' });
      process.exit();
    }
  });
}

startBot();
